import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, ArrowLeft, AlertCircle, CheckCircle2, Users } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";

export default function Admin() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [sortBy, setSortBy] = useState<"recent" | "verdict">("recent");

  // Check admin access
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              You do not have permission to access the admin panel.
            </p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: allReviews, isLoading: reviewsLoading } = trpc.reviews.getAllReviews.useQuery();
  const { data: adminAnalytics, isLoading: analyticsLoading } = trpc.reviews.getAdminAnalytics.useQuery();

  const isLoading = reviewsLoading || analyticsLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const sortedReviews = allReviews ? [...allReviews].sort((a, b) => {
    if (sortBy === "recent") {
      return new Date(b?.createdAt || 0).getTime() - new Date(a?.createdAt || 0).getTime();
    } else {
      return (a?.analysis?.verdict || "").localeCompare(b?.analysis?.verdict || "");
    }
  }) : [];

  const fakePercentage = adminAnalytics?.totalReviews
    ? Math.round((adminAnalytics.fakeCount / adminAnalytics.totalReviews) * 100)
    : 0;

  const genuinePercentage = adminAnalytics?.totalReviews
    ? Math.round((adminAnalytics.genuineCount / adminAnalytics.totalReviews) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm">
        <div className="container py-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2 mb-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Admin Panel</h1>
          <p className="text-sm text-muted-foreground">System-wide analytics and review management</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="space-y-8">
          {/* Global Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{adminAnalytics?.totalReviews || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">Across all users</p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  Genuine
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{adminAnalytics?.genuineCount || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">{genuinePercentage}% of total</p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  Fake
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">{adminAnalytics?.fakeCount || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">{fakePercentage}% of total</p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg Confidence</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">
                  {adminAnalytics?.averageConfidence
                    ? parseFloat(adminAnalytics.averageConfidence as any).toFixed(1)
                    : "0"}%
                </div>
                <p className="text-xs text-muted-foreground mt-1">System-wide average</p>
              </CardContent>
            </Card>
          </div>

          {/* All Reviews Table */}
          <Card className="border-border/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>All Reviews</CardTitle>
                  <CardDescription>Complete review history across all users</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={sortBy === "recent" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSortBy("recent")}
                  >
                    Recent
                  </Button>
                  <Button
                    variant={sortBy === "verdict" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSortBy("verdict")}
                  >
                    Verdict
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {sortedReviews.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">No reviews in the system yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>User ID</TableHead>
                        <TableHead>Review Preview</TableHead>
                        <TableHead>Verdict</TableHead>
                        <TableHead>Confidence</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedReviews.map((review) => review && (
                        <TableRow key={review.id} className="hover:bg-secondary/50">
                          <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-sm font-mono text-muted-foreground">
                            {review.userId}
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <p className="text-sm text-foreground truncate">
                              {review.reviewText.substring(0, 50)}...
                            </p>
                          </TableCell>
                          <TableCell>
                            {review.analysis ? (
                              <Badge
                                variant={
                                  review.analysis.verdict === "genuine" ? "default" : "destructive"
                                }
                              >
                                {review.analysis.verdict === "genuine" ? "Genuine" : "Fake"}
                              </Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-sm font-medium">
                            {review.analysis
                              ? `${parseFloat(review.analysis.confidenceScore as any).toFixed(1)}%`
                              : "-"}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setLocation(`/results/${review.id}`)}
                            >
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
