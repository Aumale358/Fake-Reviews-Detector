import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle2, ArrowLeft, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Results() {
  const { reviewId } = useParams<{ reviewId: string }>();
  const [, setLocation] = useLocation();

  const { data, isLoading, error } = trpc.reviews.getDetails.useQuery(
    { reviewId: parseInt(reviewId || "0") },
    { enabled: !!reviewId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <Card className="max-w-md border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Error Loading Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{error?.message || "Review not found"}</p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const analysis = data.analysis;
  if (!analysis) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Analysis Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/")} className="w-full">
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isGenuine = analysis.verdict === "genuine";
  const confidence = parseFloat(analysis.confidenceScore as any);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm">
        <div className="container py-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2 mb-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Analysis Results</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="max-w-3xl mx-auto space-y-8">
          {/* Verdict Card */}
          <Card className={`shadow-lg border-2 ${isGenuine ? "border-green-200" : "border-red-200"}`}>
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-3xl">
                  {isGenuine ? "Genuine Review" : "Fake Review"}
                </CardTitle>
                {isGenuine ? (
                  <CheckCircle2 className="h-12 w-12 text-green-600" />
                ) : (
                  <AlertCircle className="h-12 w-12 text-red-600" />
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Confidence Score */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold text-foreground">Confidence Score</label>
                  <span className="text-2xl font-bold text-primary">{confidence.toFixed(1)}%</span>
                </div>
                <Progress value={confidence} className="h-3" />
                <p className="text-xs text-muted-foreground">
                  {confidence >= 80
                    ? "Very high confidence in this assessment"
                    : confidence >= 60
                      ? "High confidence in this assessment"
                      : confidence >= 40
                        ? "Moderate confidence in this assessment"
                        : "Low confidence - review may be ambiguous"}
                </p>
              </div>

              {/* Reasoning */}
              <div className="space-y-2 pt-4 border-t border-border">
                <label className="text-sm font-semibold text-foreground">Analysis Reasoning</label>
                <p className="text-sm text-muted-foreground leading-relaxed">{analysis.reasoning}</p>
              </div>
            </CardContent>
          </Card>

          {/* Signals */}
          <Card className="border-border/40">
            <CardHeader>
              <CardTitle>Detected Signals</CardTitle>
              <CardDescription>
                Key indicators found in this review
              </CardDescription>
            </CardHeader>
            <CardContent>
              {analysis.signals && analysis.signals.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {(analysis.signals as string[]).map((signal, index) => (
                    <Badge key={index} variant="secondary" className="px-3 py-1">
                      {signal}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No specific signals detected</p>
              )}
            </CardContent>
          </Card>

          {/* Original Review */}
          <Card className="border-border/40">
            <CardHeader>
              <CardTitle>Original Review</CardTitle>
              <CardDescription>
                Submitted on {new Date(data.createdAt).toLocaleDateString()} at{" "}
                {new Date(data.createdAt).toLocaleTimeString()}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-secondary/50 rounded-lg p-4 text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words max-h-64 overflow-y-auto">
                {data.reviewText}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex gap-3">
            <Button onClick={() => setLocation("/")} className="flex-1">
              Analyze Another Review
            </Button>
            <Button variant="outline" onClick={() => setLocation("/dashboard")} className="flex-1">
              View History
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
