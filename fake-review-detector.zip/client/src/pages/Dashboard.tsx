import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, ArrowLeft, BarChart3, AlertCircle, CheckCircle2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useState } from "react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [sortBy, setSortBy] = useState<"recent" | "verdict">("recent");

  const { data: history, isLoading: historyLoading } = trpc.reviews.getHistory.useQuery();
  const { data: analytics, isLoading: analyticsLoading } = trpc.reviews.getAnalytics.useQuery();

  const isLoading = historyLoading || analyticsLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const sortedHistory = history ? [...history].sort((a, b) => {
    if (sortBy === "recent") {
      return new Date(b?.createdAt || 0).getTime() - new Date(a?.createdAt || 0).getTime();
    } else {
      return (a?.analysis?.verdict || "").localeCompare(b?.analysis?.verdict || "");
    }
  }) : [];

  const fakePercentage = analytics?.totalReviews
    ? Math.round((analytics.fakeCount / analytics.totalReviews) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm">
        <div className="container py-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2 mb-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Your Dashboard</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="space-y-8">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics?.totalReviews || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">Analyzed so far</p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  Genuine
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{analytics?.genuineCount || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {analytics?.totalReviews ? Math.round(((analytics.genuineCount || 0) / analytics.totalReviews) * 100) : 0}% of total
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  Fake
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">{analytics?.fakeCount || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {fakePercentage}% of total
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg Confidence</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">
                  {analytics?.averageConfidence ? parseFloat(analytics.averageConfidence as any).toFixed(1) : "0"}%
                </div>
                <p className="text-xs text-muted-foreground mt-1">Average score</p>
              </CardContent>
            </Card>
          </div>

          {/* Review History */}
          <Card className="border-border/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Review History</CardTitle>
                  <CardDescription>All your submitted reviews and their analysis results</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={sortBy === "recent" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSortBy("recent")}
                  >
                    Recent
                  </Button>
                  <Button
                    variant={sortBy === "verdict" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSortBy("verdict")}
                  >
                    Verdict
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {sortedHistory.length === 0 ? (
                <div className="text-center py-12">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">No reviews analyzed yet</p>
                  <Button onClick={() => setLocation("/")} className="mt-4">
                    Analyze Your First Review
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Review Preview</TableHead>
                        <TableHead>Verdict</TableHead>
                        <TableHead>Confidence</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedHistory.map((review) => review && (
                        <TableRow key={review.id} className="hover:bg-secondary/50">
                          <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <p className="text-sm text-foreground truncate">
                              {review.reviewText.substring(0, 50)}...
                            </p>
                          </TableCell>
                          <TableCell>
                            {review.analysis ? (
                              <Badge
                                variant={
                                  review.analysis.verdict === "genuine" ? "default" : "destructive"
                                }
                              >
                                {review.analysis.verdict === "genuine" ? "Genuine" : "Fake"}
                              </Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-sm font-medium">
                            {review.analysis
                              ? `${parseFloat(review.analysis.confidenceScore as any).toFixed(1)}%`
                              : "-"}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setLocation(`/results/${review.id}`)}
                            >
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
