import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, Loader2, BarChart3, History } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Home() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [reviewText, setReviewText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const submitReviewMutation = trpc.reviews.submit.useMutation({
    onSuccess: (data) => {
      setIsAnalyzing(false);
      setReviewText("");
      toast.success("Review analyzed successfully!");
      setLocation(`/results/${data.reviewId}`);
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast.error(error.message || "Failed to analyze review");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewText.trim()) {
      toast.error("Please enter a review");
      return;
    }
    setIsAnalyzing(true);
    await submitReviewMutation.mutateAsync({ reviewText });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <div className="max-w-md text-center space-y-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-foreground">Fake Review Detector</h1>
            <p className="text-lg text-muted-foreground">
              Analyze reviews with AI-powered authenticity detection
            </p>
          </div>
          <p className="text-sm text-muted-foreground">
            Sign in to start analyzing reviews and build your detection history.
          </p>
          <Button size="lg" className="w-full" onClick={() => (window.location.href = getLoginUrl())}>
            Sign In with Manus
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-foreground">Fake Review Detector</h1>
            <p className="text-sm text-muted-foreground">Welcome, {user?.name}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setLocation("/dashboard")}>
              <History className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
            {user?.role === "admin" && (
              <Button variant="outline" size="sm" onClick={() => setLocation("/admin")}>
                <BarChart3 className="h-4 w-4 mr-2" />
                Admin
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="space-y-4 text-center">
            <h2 className="text-3xl font-bold text-foreground">Analyze Review Authenticity</h2>
            <p className="text-lg text-muted-foreground">
              Paste or type a review below to get an AI-powered assessment of its authenticity. Our system analyzes linguistic patterns, sentiment, and behavioral indicators to determine if a review is genuine or fake.
            </p>
          </div>

          {/* Submission Form */}
          <Card className="shadow-lg border-border/40">
            <CardHeader>
              <CardTitle>Submit a Review</CardTitle>
              <CardDescription>
                Enter the review text you want to analyze. Minimum 10 characters required.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="review" className="text-sm font-medium text-foreground">
                    Review Text
                  </label>
                  <Textarea
                    id="review"
                    placeholder="Paste or type the review here..."
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    disabled={isAnalyzing}
                    className="min-h-32 resize-none text-base"
                  />
                  <div className="flex justify-between items-center">
                    <p className="text-xs text-muted-foreground">
                      {reviewText.length} / 5000 characters
                    </p>
                    {reviewText.length < 10 && reviewText.length > 0 && (
                      <p className="text-xs text-destructive">Minimum 10 characters required</p>
                    )}
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={isAnalyzing || reviewText.length < 10}
                  className="w-full"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Review"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Genuine Reviews
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Authentic reviews with natural language, specific details, and balanced sentiment.
              </CardContent>
            </Card>

            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  Fake Reviews
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Suspicious reviews with generic language, extreme sentiment, or artificial patterns.
              </CardContent>
            </Card>
          </div>

          {/* Features */}
          <Card className="bg-card/50 border-border/40">
            <CardHeader>
              <CardTitle className="text-lg">How It Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex gap-3">
                  <Badge className="h-6 w-6 flex items-center justify-center flex-shrink-0 rounded-full">1</Badge>
                  <div>
                    <p className="font-medium text-foreground">Submit Your Review</p>
                    <p className="text-sm text-muted-foreground">Paste any review text you want to analyze</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Badge className="h-6 w-6 flex items-center justify-center flex-shrink-0 rounded-full">2</Badge>
                  <div>
                    <p className="font-medium text-foreground">AI Analysis</p>
                    <p className="text-sm text-muted-foreground">Our system analyzes linguistic patterns and indicators</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Badge className="h-6 w-6 flex items-center justify-center flex-shrink-0 rounded-full">3</Badge>
                  <div>
                    <p className="font-medium text-foreground">Get Results</p>
                    <p className="text-sm text-muted-foreground">Receive a verdict with confidence score and reasoning</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
