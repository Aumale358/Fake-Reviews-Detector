import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return createAuthContext({ role: "admin" });
}

describe("reviews router", () => {
  describe("submit procedure", () => {
    it("should reject reviews shorter than 10 characters", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.submit({ reviewText: "short" });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("BAD_REQUEST");
        expect(error.message).toContain("at least 10 characters");
      }
    });

    it("should reject empty reviews", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.submit({ reviewText: "" });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("BAD_REQUEST");
      }
    });

    it("should reject reviews longer than 5000 characters", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const longText = "a".repeat(5001);

      try {
        await caller.reviews.submit({ reviewText: longText });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("BAD_REQUEST");
        expect(error.message).toContain("less than 5000 characters");
      }
    });

    it("should require authentication", async () => {
      const ctx = createAuthContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.submit({ reviewText: "This is a valid review text" });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getAnalytics procedure", () => {
    it("should return analytics for authenticated user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const analytics = await caller.reviews.getAnalytics();

      expect(analytics).toBeDefined();
      expect(analytics.totalReviews).toBeGreaterThanOrEqual(0);
      expect(analytics.fakeCount).toBeGreaterThanOrEqual(0);
      expect(analytics.genuineCount).toBeGreaterThanOrEqual(0);
      expect(analytics.averageConfidence).toBeDefined();
    });

    it("should require authentication", async () => {
      const ctx = createAuthContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getAnalytics();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getAllReviews procedure (admin only)", () => {
    it("should allow admin users to get all reviews", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const reviews = await caller.reviews.getAllReviews();

      expect(Array.isArray(reviews)).toBe(true);
    });

    it("should deny non-admin users", async () => {
      const ctx = createAuthContext({ role: "user" });
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getAllReviews();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
        expect(error.message).toContain("Admin access required");
      }
    });

    it("should require authentication", async () => {
      const ctx = createAdminContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getAllReviews();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getAdminAnalytics procedure (admin only)", () => {
    it("should allow admin users to get global analytics", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const analytics = await caller.reviews.getAdminAnalytics();

      expect(analytics).toBeDefined();
      expect(analytics.totalReviews).toBeGreaterThanOrEqual(0);
      expect(analytics.fakeCount).toBeGreaterThanOrEqual(0);
      expect(analytics.genuineCount).toBeGreaterThanOrEqual(0);
      expect(analytics.averageConfidence).toBeDefined();
    });

    it("should deny non-admin users", async () => {
      const ctx = createAuthContext({ role: "user" });
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getAdminAnalytics();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
        expect(error.message).toContain("Admin access required");
      }
    });

    it("should require authentication", async () => {
      const ctx = createAdminContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getAdminAnalytics();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getHistory procedure", () => {
    it("should return review history for authenticated user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const history = await caller.reviews.getHistory();

      expect(Array.isArray(history)).toBe(true);
    });

    it("should require authentication", async () => {
      const ctx = createAuthContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getHistory();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getDetails procedure", () => {
    it("should require authentication", async () => {
      const ctx = createAuthContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getDetails({ reviewId: 1 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("should return not found for non-existent review", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reviews.getDetails({ reviewId: 999999 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("NOT_FOUND");
      }
    });
  });
});
