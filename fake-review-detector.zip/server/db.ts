import { desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, reviews, analysisResults } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createReview(userId: number, reviewText: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(reviews).values({
    userId,
    reviewText,
  });

  return result;
}

export async function getUserReviews(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(reviews)
    .where(eq(reviews.userId, userId))
    .orderBy((r) => desc(r.createdAt));

  return result;
}

export async function getReviewWithAnalysis(reviewId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const review = await db
    .select()
    .from(reviews)
    .where(eq(reviews.id, reviewId))
    .limit(1);

  if (!review.length) return null;

  const analysis = await db
    .select()
    .from(analysisResults)
    .where(eq(analysisResults.reviewId, reviewId))
    .limit(1);

  return {
    ...review[0],
    analysis: analysis[0] || null,
  };
}

export async function createAnalysisResult(
  reviewId: number,
  verdict: "fake" | "genuine",
  confidenceScore: number,
  reasoning: string,
  signals: string[]
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(analysisResults).values({
    reviewId,
    verdict,
    confidenceScore: confidenceScore.toString(),
    reasoning,
    signals,
  });

  return result;
}

export async function getAllReviews() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(reviews)
    .orderBy((r) => desc(r.createdAt));

  return result;
}

export async function getUserAnalytics(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const userReviews = await db
    .select()
    .from(reviews)
    .where(eq(reviews.userId, userId));

  const analysisData = await db
    .select()
    .from(analysisResults)
    .where(
      inArray(
        analysisResults.reviewId,
        userReviews.map((r) => r.id)
      )
    );

  const fakeCount = analysisData.filter((a) => a.verdict === "fake").length;
  const genuineCount = analysisData.filter((a) => a.verdict === "genuine").length;

  return {
    totalReviews: userReviews.length,
    fakeCount,
    genuineCount,
    averageConfidence:
      analysisData.length > 0
        ? (
            analysisData.reduce((sum, a) => sum + parseFloat(a.confidenceScore as any), 0) /
            analysisData.length
          ).toFixed(2)
        : "0.00",
  };
}

export async function getGlobalAnalytics() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const allReviews = await db.select().from(reviews);
  const allAnalysis = await db.select().from(analysisResults);

  const fakeCount = allAnalysis.filter((a) => a.verdict === "fake").length;
  const genuineCount = allAnalysis.filter((a) => a.verdict === "genuine").length;

  return {
    totalReviews: allReviews.length,
    fakeCount,
    genuineCount,
    averageConfidence:
      allAnalysis.length > 0
        ? (
            allAnalysis.reduce((sum, a) => sum + parseFloat(a.confidenceScore as any), 0) /
            allAnalysis.length
          ).toFixed(2)
        : "0.00",
  };
}
