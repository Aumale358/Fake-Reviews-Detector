import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createReview,
  createAnalysisResult,
  getUserReviews,
  getReviewWithAnalysis,
  getUserAnalytics,
  getAllReviews,
  getGlobalAnalytics,
} from "./db";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  reviews: router({
    submit: protectedProcedure
      .input(
        z.object({
          reviewText: z.string().min(10, "Review must be at least 10 characters").max(5000, "Review must be less than 5000 characters"),
        })
      )
      .mutation(async ({ ctx, input }) => {

        // Create review record
        const reviewResult = await createReview(ctx.user.id, input.reviewText);
        const reviewId = (reviewResult as any).insertId;

        // Call LLM for analysis
        const llmResponse = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are an expert at detecting fake reviews. Analyze the given review and determine if it's fake or genuine. 
              Return a JSON response with the following structure:
              {
                "verdict": "fake" or "genuine",
                "confidenceScore": a number between 0 and 100,
                "reasoning": a brief explanation of your verdict,
                "signals": an array of specific indicators found in the review (e.g., "excessive praise", "generic language", "suspicious patterns")
              }`,
            },
            {
              role: "user",
              content: `Please analyze this review: "${input.reviewText}"`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "review_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  verdict: {
                    type: "string",
                    enum: ["fake", "genuine"],
                    description: "Whether the review is fake or genuine",
                  },
                  confidenceScore: {
                    type: "number",
                    description: "Confidence score between 0 and 100",
                  },
                  reasoning: {
                    type: "string",
                    description: "Explanation of the verdict",
                  },
                  signals: {
                    type: "array",
                    items: { type: "string" },
                    description: "Array of specific indicators found",
                  },
                },
                required: ["verdict", "confidenceScore", "reasoning", "signals"],
                additionalProperties: false,
              },
            },
          },
        });

        const analysisContent = llmResponse.choices[0]?.message.content;
        const contentStr = typeof analysisContent === "string" ? analysisContent : undefined;
        if (!contentStr) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to analyze review",
          });
        }

        const analysis = JSON.parse(contentStr);

        // Save analysis result
        await createAnalysisResult(
          reviewId,
          analysis.verdict,
          analysis.confidenceScore,
          analysis.reasoning,
          analysis.signals
        );

        return {
          reviewId,
          ...analysis,
        };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      const userReviews = await getUserReviews(ctx.user.id);

      // Get analysis for each review
      const reviewsWithAnalysis = await Promise.all(
        userReviews.map((review: any) => getReviewWithAnalysis(review.id))
      );

      return reviewsWithAnalysis;
    }),

    getDetails: protectedProcedure
      .input(z.object({ reviewId: z.number() }))
      .query(async ({ ctx, input }) => {
        const reviewWithAnalysis = await getReviewWithAnalysis(input.reviewId);

        if (!reviewWithAnalysis) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Review not found",
          });
        }

        // Verify ownership
        if (reviewWithAnalysis.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You don't have permission to view this review",
          });
        }

        return reviewWithAnalysis;
      }),

    getAnalytics: protectedProcedure.query(async ({ ctx }) => {
      return await getUserAnalytics(ctx.user.id);
    }),

    getAllReviews: protectedProcedure.query(async ({ ctx }) => {
      // Admin only
      if (ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Admin access required",
        });
      }

      const allReviews = await getAllReviews();

      // Get analysis for each review
      const reviewsWithAnalysis = await Promise.all(
        allReviews.map((review: any) => getReviewWithAnalysis(review.id))
      );

      return reviewsWithAnalysis;
    }),

    getAdminAnalytics: protectedProcedure.query(async ({ ctx }) => {
      // Admin only
      if (ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Admin access required",
        });
      }


      return await getGlobalAnalytics();
    }),
  }),
});

export type AppRouter = typeof appRouter;
